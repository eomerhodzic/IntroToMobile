package com.example.oistiba;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RegisterLoginActivity extends AppCompatActivity {
    ViewPager vp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register);

        Bundle extras = getIntent().getExtras();

        vp = findViewById(R.id.viewPager);
        setupViewPager(vp);

        if (extras.get("type").equals("register")) {
            vp.setCurrentItem(0);
        } else {
            vp.setCurrentItem(1);
        }

    }

    public void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new RegisterFragment());
        adapter.addFragment(new LoginFragment());
        viewPager.setAdapter(adapter);
    }
}
