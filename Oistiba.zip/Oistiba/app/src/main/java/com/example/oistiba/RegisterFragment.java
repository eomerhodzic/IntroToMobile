package com.example.oistiba;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class RegisterFragment extends Fragment {
    Button registerBtn;

    EditText email;
    EditText password;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        registerBtn = view.findViewById(R.id.RegisterBtn);

        email = view.findViewById(R.id.emailInput);
        password = view.findViewById(R.id.passwordInput);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<User> users = Database.getDatabase(getContext()).userDAO().getAllUsers();

                for(User user: users) {
                    if (user.getEmail().equals(email.getText().toString())) {

                        Toast alreadyRegisteredToast = Toast.makeText(getContext(), "Korisnik već postoji! Molimo ulogujte se sa već postojećim podacima.", Toast.LENGTH_LONG);
                        alreadyRegisteredToast.setGravity(Gravity.CENTER, 0, 0);
                        LinearLayout toastLayout = (LinearLayout) alreadyRegisteredToast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        toastTV.setTextSize(25);
                        alreadyRegisteredToast.show();
                       return;
                    }
                }

                User newUser = new User(email.getText().toString(), password.getText().toString());
                Database.getDatabase(getContext()).userDAO().insertUser(newUser);

                Intent registered = new Intent(getContext(), CameraActivity.class);
                registered.putExtra("email", email.getText().toString());
                startActivity(registered);

                Toast registeredToast = Toast.makeText(getContext(), "Uspješna registracija! Hvala.", Toast.LENGTH_SHORT);
                registeredToast.setGravity(Gravity.CENTER, 0, 0);
                LinearLayout toastLayout = (LinearLayout) registeredToast.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                toastTV.setTextSize(20);
                registeredToast.show();
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_register, container, false);
    }
}
