package com.example.oistiba;

import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@android.arch.persistence.room.Database(entities = {User.class}, version = 1)
public abstract class Database extends RoomDatabase {
    private static Database INSTANCE = null;
    public abstract UserDAO userDAO();

    public static Database getDatabase(Context context){
        if(INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(context, Database.class, "ocistiDB").allowMainThreadQueries().build();
        }

        return INSTANCE;
    }
}
