package com.example.oistiba;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class LoginFragment extends Fragment {
    Button loginBtn;
    Button backToRegbtn;
    EditText email;
    EditText password;
    int userFound =0;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        loginBtn = view.findViewById(R.id.LoginBtn);
        backToRegbtn = view.findViewById(R.id.backToReg);

        email = view.findViewById(R.id.emailInput);
        password = view.findViewById(R.id.passwordInput);

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<User> users = Database.getDatabase(getContext()).userDAO().getAllUsers();

                for (User user : users) {
                    if (user.getEmail().equals(email.getText().toString()) &&
                            user.getPassword().equals(password.getText().toString())) {
                        Toast toast = Toast.makeText(getContext(), "Uspješno!", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        LinearLayout toastLayout = (LinearLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        toastTV.setTextSize(25);
                        toast.show();

                        Intent intent = new Intent(getContext(), CameraActivity.class);
                        intent.putExtra("email", email.getText().toString());
                        startActivity(intent);
                            userFound=1;

                    }
                    else if (user.getEmail().equals(email.getText().toString()) &&
                            !user.getPassword().equals(password.getText().toString())){
                        Toast toast = Toast.makeText(getContext(), "Pogrešna šifra! Molimo, ulogujte se ponovo.", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        LinearLayout toastLayout = (LinearLayout) toast.getView();
                        TextView toastTV = (TextView) toastLayout.getChildAt(0);
                        toastTV.setTextSize(25);
                        toast.show();
                    }
                }
                if(userFound == 0) {
                    Toast toast2 = Toast.makeText(getContext(), "Korisnik ne postoji! Molimo, registrujte se.", Toast.LENGTH_SHORT);
                toast2.setGravity(Gravity.CENTER, 0, 0);
                LinearLayout toastLayout = (LinearLayout) toast2.getView();
                TextView toastTV = (TextView) toastLayout.getChildAt(0);
                toastTV.setTextSize(25);
                toast2.show();
                }

            }
        });

        backToRegbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Intent intent1 = new Intent(getContext(), RegisterLoginActivity.class);
                    intent1.putExtra("type", "register");
                    startActivity(intent1);

            }
        });
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.activity_login, container, false);
    }
}
